This source code was used in generating the "PIC18F46J50 FS USB Demo Board Factory Hex 22 July 2009.hex"
file.  This HID+MSD composite project was started from the MCHPFSUSB v2.3 version of the HID+MSD composite
firmware example.  A few modifications were made (such as increasing the MSD drive size) to make the
demo more interesting, and to increase the amount of error checking and case handling in the MSD code.

This source code is provided for reference purposes.  Please note however, that since this source
is an archive of the project used to create the
"PIC18F46J50 FS USB Demo Board Factory Hex 22 July 2009.hex" file, this source code is not planned to get
updated in future releases of the MCHPFSUSB package.  If starting a new development project that will 
be similar to this project, it is suggested to consider using the latest demo firmware project(s) in the
MCHPFSUSB package, instead of this archive version.

The "PIC18F46J50 FS USB Demo Board Factory Hex 22 July 2009.hex" was created by:

1.  Programming the PIC18F46J50 silicon with the HID bootloader (from MCHPFSUSB v2.4) firmware.
2.  Using the HID bootloader to program the output hex file from the HID+MSD composite firmware
	included in this source archive.
3.  Allowing the HID+MSD composite firmware to run and enumerate once.
4.  Manually modifying the contents of the MSD drive volume by copying the Readme.txt and
	HID PnP Demo (PID 0x0054).zip files onto the drive using the Windows Explorer.
5.  Reading the entire memory contents out of flash using an ICSP(tm) programmer/debugger,
	and then exporting the contents to the
	"PIC18F46J50 FS USB Demo Board Factory Hex 22 July 2009.hex" file.
