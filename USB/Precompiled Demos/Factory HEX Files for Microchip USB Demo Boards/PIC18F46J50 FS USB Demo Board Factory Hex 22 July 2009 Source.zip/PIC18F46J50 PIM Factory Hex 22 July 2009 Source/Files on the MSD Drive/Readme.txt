This file is stored in the internal flash memory on the PIC18F46J50 microcontroller.
This file may be modified and saved; the flash memory will be updated with the changes,
provided that there is enough free drive space available (both on the drive as a whole,
and the FAT table).

The firmware currently programmed on this microcontroller is that contained
in the "PIC18F46J50 FS USB Demo Board Factory Hex 22 July 2009.hex" file.  If
at anytime you wish to restore the device to the factory original state,
simply reprogram the microcontroller with this hex file.  This file is contained
in the MCHPFSUSB USB framework package.  The latest version of this
package can be downloaded from the Microchip USB design center:

http://www.microchip.com/usb


The factory hex file currently programmed on the PIC18F46J50 microcontroller
enumerates as a "composite" USB device, consisting of a Mass Storage Device (MSD)
class interface and a Human Interface Device (HID) class interface.  The MSD interface
is responsible for creating the drive volume that this Readme.txt file resides on.

The HID class interface is intended to be used for demo purposes, showing basic USB read
and write capability with the PC application: 
"HID PnP Demo Composite HID+MSD Demo only (PID=0x0054).exe".  To run the demo,
simply double click the executable.

Note: In order to run the executable, you must have already installed the Microsoft
.NET framework version 2.0 or later redistributable package.  Vista comes with this
pre-installed, but for XP the package can be obtained from:
http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=en

The PC application should auto-detect the USB device, and begin communicating with the 
firmware.  Try experimenting with the application by pressing the S2 (RB2) pushbutton, 
playing with the Toggle LED(s) button, and by applying an analog voltage to the RA0 (AN0) 
I/O pin.  When the PIC18F46J50 FS USB Demo Board is used with either the HPC Explorer 
board, or PIC18 Explorer board, RA0 will have an analog potentiometer attached to it.  
If the PIC18F46J50 FS USB Demo Board is used stand alone, try applying an externally 
generated adjustable analog voltage to the RA0 I/O pin.  Also try disconnecting the USB
cable from the demo board.  The PC application should automatically detect this event 
and respond dynamically for a smooth "Plug n Play" experience.

The factory hex file which ships on the PIC18F46J50 FS USB Demo Board also includes
a USB bootloader.  This bootloader can be used to program new .hex firmware files into
the PIC18F46J50 directly over the USB cable, without needing to use a dedicated ICSP(TM)
programmer.  To enter bootload mode, press and hold down the S2 (RB2) pushbutton.  
While still holding down the S2 pushbutton, momentarily tap and release the MCLR 
pushbutton to reset the microcontroller.  After coming out of reset, the firmware will 
do a quick I/O pin check of the RB2 pin state and enter bootloader mode if it detects 
the I/O pin is low (user holding down pushbutton).

Once in bootload mode, the device should enumerate as a simple HID class device only (in
demo mode the device enumerates as a composite HID+MSD device).  When in bootload mode, new
firmware .hex files may be programmed using the "HIDBootLoader.exe" PC application.  This
program is contained in the MCHPFSUSB USB framework package.  

Full source code for the USB bootloader firmware, the USB bootloader PC application,
the HID+MSD demo firmware, and the HID PnP demo PC application are all available and
are included in the MCHPFSUSB package.  The package also includes a large variety of
other USB example projects (firmware and PC), as well as USB drivers and other resources.
Many of the example projects contained in the MCHPFSUSB package are intended to be
used directly with the PIC18F46J50 FS USB Demo Board.  The package contains
precompiled .hex files for the other demos which can be directly used with this demo board.

See the MCHPFSUSB release notes and the getting started directory for additional details
on how to program and use the other demo firmware examples (assuming the default
MCHPFSUSB installation directory):

C:\Microchip Solutions\Microchip\Usb\Documentation\Getting Started 